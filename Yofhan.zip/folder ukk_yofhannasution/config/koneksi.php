<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'fotogaleri';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);

?>